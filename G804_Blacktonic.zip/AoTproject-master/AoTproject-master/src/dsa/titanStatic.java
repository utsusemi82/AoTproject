/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dsa;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Yap Yoong Siew
 */
public class titanStatic {
    public static void main(String[] args){
        boolean titancontinue = true;
        do{
            System.out.println("Enter the number of titans (-1 to quit): ");
            Scanner in = new Scanner(System.in);
            int numberOfTitans = in.nextInt(); 
            if(numberOfTitans == -1){
                titancontinue = false;
                break;
            }
            System.out.println("Generating " + numberOfTitans + "Titans....");
            titansPriorityQueue priority = new titansPriorityQueue();
            titansPriorityQueue priority1 = new titansPriorityQueue();
            titansPriorityQueue priority2 = new titansPriorityQueue();
            //the linkedList is unsorted, the search for largest titan happens only when dequeue() is called
            for(int i = 0; i < numberOfTitans; i++){
                Titans curr = probability(i+1);
                System.out.println(curr.toString());
                priority.enqueue(curr);
                priority1.enqueue(curr);
                priority2.enqueue(curr);
            }

            killSequence(priority2);

            //extra feature part Titan evaluation and killing priority
            LinkedList<characteristic> list = new LinkedList<>();
            Scanner sc = new Scanner(System.in);
            int size = 0;

            String file_path = "characteristics.txt";

            //2.1
            //store and print data 
            try {
                File f = new File(file_path);
                Scanner inputStream = new Scanner(new FileInputStream(f));
                boolean isAdded = false;

                while (inputStream.hasNextLine()) {
                    String name = inputStream.nextLine();
                    int height = Integer.parseInt(inputStream.nextLine());
                    int weight = Integer.parseInt(inputStream.nextLine());
                    int strength = Integer.parseInt(inputStream.nextLine());
                    int agility = Integer.parseInt(inputStream.nextLine());
                    int intelligence = Integer.parseInt(inputStream.nextLine());
                    int coordination = Integer.parseInt(inputStream.nextLine());
                    int leadership = Integer.parseInt(inputStream.nextLine());
                    size++;

                    characteristic character = new characteristic(name, height, weight, strength, agility, intelligence, coordination, leadership);
                    isAdded = list.add(character);
    //                System.out.println(character.toString());
    //                System.out.println();

                    if (isAdded) {
                        continue;
                    } else {
                        System.out.println("Not added!");
                        break;
                    }

                }
                inputStream.close();
            } catch (FileNotFoundException e) {
                System.out.println(e);
            }
            third_extra_feature_runOrnot(numberOfTitans, list, priority);
    }while(titancontinue);
        
        
    }
    
    public static Titans probability(int index){
        Random r = new Random();
        Titans titan;
        if(r.nextInt(101)>30){
            boolean normal = true;
            int height;
            double temp = r.nextDouble();//for height
            if(temp < 0.3){
                height = 1; //risk 1
            }
            else if(temp < 0.6){
                height = 2;//risk 2
            }
            else{
                height = 3;//risk 3
            }
            int legs;
            temp = r.nextDouble();//for legs
            if(temp < 0.3){
                legs = 1; //risk 1
            }
            else if(temp < 0.6){
                legs = 2; //risk 2
            }
            else{
                legs = 3; //risk 3
            }
            int speed;
            temp = r.nextDouble();//for speed
            if(temp < 0.3){
                speed = 1; //risk 1
            }
            else if(temp < 0.6){
                speed = 2; //risk 2
            }
            else{
                speed = 3;//risk 3
            }
            int walk;
            temp = r.nextDouble();//for walking pattern
            if(temp < 0.3){
                walk = 1; //risk 1
            }
            else if(temp < 0.6){
                walk = 2; //risk 2
            }
            else{
                walk = 3; //risk 3
            }
            int climb;
            temp = r.nextDouble();//for climb
            if(temp < 0.5){
                climb = 1; //risk 1
            }
            else{
                climb = 3; //risk 3
            }
            titan = new Titans(normal, height, legs, speed, walk, climb, index);
        }
        else{
            boolean normal = false;
            double temp = r.nextDouble();
            int risk;
            if(temp < 0.5){
                risk = 15;//abnormal
            }
            else{
                risk = 19;//one of nine
            }
            titan = new Titans(normal, risk, index);
        }
        return titan;
    }
    
    public static void killSequence(titansPriorityQueue e){
        System.out.println("Sequence to be killed :");
        int totalDistance = e.dequeue().getIndex(); //index of first titan
        System.out.print("Titan" + totalDistance); //totalDistance==index of fist titan   
        int size = e.getSize();
        for(int i = 0; i < size; i++){
            int n = e.dequeue().getIndex();
            totalDistance += n;
            System.out.print("--> Titan " + n);
        }
        System.out.println("");
        System.out.println("Total Distance moved : " + totalDistance);
    }
    
    //extra feature part
    public static void third_extra_feature_runOrnot(int n, LinkedList<characteristic> list,titansPriorityQueue priority){
        boolean statustoContinue = true;
        do{
            System.out.print("Enter character you want to fight: ");
            Scanner in = new Scanner(System.in);
            String name = in.nextLine();
            Titans toBeKilled = priority.peek();


            for(characteristic c : list){
                if(c.getName().equals(name)){
                    if((c.getAgility()+c.getStrength()) < toBeKilled.getRisk()){
                        System.out.println("Run!");
                    }
                    else{
                        System.out.println("Kill the Titan!!!!");
                        int capability = c.getAgility()+c.getStrength();
                        third_extra_feature_halfwayEnter(n, priority, capability);
                        statustoContinue = false;
                        break;
                        
                    }
                }
            }

            
            if (name.equalsIgnoreCase("quit")) {
                statustoContinue = false;
            }
        }while(statustoContinue);
    }
    public static void third_extra_feature_halfwayEnter(int numberOfTitans, titansPriorityQueue priority, int capability){
        Random r = new Random();
        int globalTime = 0;
        int localIndex = 0;
        int prevIndex = 0;
        int probabilityOfEnter = 30;

        while(!priority.isEmpty()){
            probabilityOfEnter -=0.1;
            if(r.nextInt(101)>probabilityOfEnter){
                
                if(localIndex == 0 && globalTime == 0){
                    System.out.println("timestep " + globalTime++);
                    System.out.println("moving to titan " + priority.peek().getIndex());
                    System.out.println("now at index " + localIndex);
                    if(localIndex < priority.peek().getIndex()) {
                        localIndex++;
                    }
                    else if(localIndex > priority.peek().getIndex()) {
                        localIndex--;
                    }
                    System.out.println("");
                }
                else{
                    System.out.println("timestep " + globalTime++);
                    System.out.println("moving to titan" + priority.peek().getIndex());
                    System.out.println("now at index " + (localIndex));
                    if(localIndex < priority.peek().getIndex()) {
                        localIndex++;
                    }
                    else if(localIndex > priority.peek().getIndex()){
                        localIndex--;
                    }
                    else{
                        System.out.println("Reached titan " + priority.dequeue());
                        System.out.println("KILLED!");
                    }
                    System.out.println("");
                    
                }
//                else if(localIndex == 0 && globalTime != 0){
//                    prevIndex = priority.peek().getIndex();
//                    System.out.println("killed titan " + priority.peek().getIndex());
//                    priority.dequeue();
//                    if(priority.getSize() != 1)
//                        localIndex = Math.abs(priority.peek().getIndex() - prevIndex);
//                    System.out.println("");
//                    
//                }
                
            }
            else{
                System.out.println("New titan coming in!");
                Titans curr = probability(numberOfTitans++);
                System.out.println(curr.toString());
                System.out.println("");
                priority.enqueue(curr);
                if(capability<curr.getRisk()){
                    System.out.println("Run!");
                    break;
                }
                

            }
        }
    }
    
}

