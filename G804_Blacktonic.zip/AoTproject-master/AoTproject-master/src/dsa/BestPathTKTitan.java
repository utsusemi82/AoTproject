/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsa;

/**
 *
 * @author user
 */

import java.util.*;
 
class BestPathTKTitan {
    // Function to form edge between
    // two vertices src and dest
    static void addEdge(ArrayList<ArrayList<Integer>> adj, int src, int dest){
        adj.get(src).add(dest);
        adj.get(dest).add(src);
    }
 
    // Function which finds all the paths
    // and stores it in paths array
    static void find_paths(ArrayList<ArrayList<Integer>> paths, ArrayList<Integer> path,
                    ArrayList<ArrayList<Integer>> parent, int vertices, int destination) {
        // Base Case
        if (destination == -1) {
            paths.add(new ArrayList<>(path));
            return;
        }
 
        // Loop for all the parents
        // of the given vertex
        for (int par : parent.get(destination)) {
 
            // Insert the current
            // vertex in path
            path.add(destination);
 
            // Recursive call for its parent
            find_paths(paths, path, parent, vertices, par);
 
            // Remove the current vertex
            path.remove(path.size()-1);
        }
    }
 
    // Function which performs bfs
    // from the given source vertex
    static void bfs(ArrayList<ArrayList<Integer>> adj, ArrayList<ArrayList<Integer>> parent,
             int vertices, int source) {
       
        // dist will contain shortest distance
        // from start to every other vertex
          int[] dist = new int[vertices];
          Arrays.fill(dist, Integer.MAX_VALUE);
 
        Queue<Integer> queue = new LinkedList<>();
 
        // Insert source vertex in queue and make
        // its parent -1 and distance 0
        queue.offer(source);
           
        parent.get(source).clear();
          parent.get(source).add(-1);
       
        dist[source] = 0;
 
        // Until Queue is empty
        while (!queue.isEmpty()) {
            int u = queue.poll();
            
            for (int v : adj.get(u)) {
                if (dist[v] > dist[u] + 1) {
 
                    // A shorter distance is found
                    // So erase all the previous parents
                    // and insert new parent u in parent[v]
                    dist[v] = dist[u] + 1;
                    queue.offer(v);
                    parent.get(v).clear();
                    parent.get(v).add(u);
                }
                else if (dist[v] == dist[u] + 1) {
 
                    // Another candidate parent for
                    // shortes path found
                    parent.get(v).add(u);
                }
            }
        }
    }
 
    // Function which prints all the paths
    // from start to end
    static void printShortestPaths(ArrayList<ArrayList<Integer>> adj, int vertices, int source, int destination){
        ArrayList<ArrayList<Integer>> paths = new ArrayList<>();
        ArrayList<Integer> path = new ArrayList<>();
        ArrayList<ArrayList<Integer>> parent = new ArrayList<>();
         
        for(int i = 0; i < vertices; i++){
            parent.add(new ArrayList<>());
        }
       
        // Function call to bfs
        bfs(adj, parent, vertices, source);
 
        // Function call to find_paths
        find_paths(paths, path, parent, vertices, destination);
 
        paths.stream().map(v -> {
            // Since paths contain each
            // path in reverse order,
            // so reverse it
            Collections.reverse(v);
            return v; 
        }
                
        ).map(v -> {
            // Print node for the current path
            v.forEach(u -> {
                System.out.print(u + " ");
            }
            );
            return v;
        }
                
        ).forEachOrdered(_item -> {
            System.out.println();
        }
                
        );
    }
   
    public static void main (String[] args)
    {
      // Number of vertices
      int n = 16;
 
      // array of vectors is used
      // to store the graph
      // in the form of an adjacency list
      ArrayList<ArrayList<Integer>> adj = new ArrayList<>();
      for(int i = 0; i < n; i++){
          adj.add(new ArrayList<>());
      }
       
      // Given Graph
        addEdge(adj, 0, 1);
        addEdge(adj, 0, 5);
        addEdge(adj, 0, 7);
        addEdge(adj, 1, 2);
        addEdge(adj, 1, 4);
        addEdge(adj, 1, 6);
        addEdge(adj, 2, 3);
        addEdge(adj, 2, 13);
        addEdge(adj, 2, 11);
        addEdge(adj, 3, 10);
        addEdge(adj, 4, 6);
        addEdge(adj, 4, 10);
        addEdge(adj, 5, 6);
        addEdge(adj, 5, 12);
        addEdge(adj, 5, 7);
        addEdge(adj, 6, 8);
        addEdge(adj, 6, 15);
        addEdge(adj, 7, 9);
        addEdge(adj, 8, 10);
        addEdge(adj, 9, 12);
        addEdge(adj, 9, 15);
        addEdge(adj, 10, 14);
        addEdge(adj, 11, 13);
        addEdge(adj, 13, 14);
        addEdge(adj, 14, 15);
         
      // Given source and destination
      int source = 0;
      int destination = n - 1;
      while(destination >= 0 && destination < 16){
        Scanner sc = new Scanner(System.in);
          System.out.print("BFS: Enter the location of titan (int) : ");
        // Number of vertices
        destination = sc.nextInt();
      // Function Call
        if(destination >= 0 && destination < 16)
            printShortestPaths(adj, n, source, destination);
      }
 
    }
}
   
//    public static void main (String[] args)
//    {
//        int n = 0;
//        while(n >= 0 && n < 16){
//        Scanner sc = new Scanner(System.in);
//          System.out.print("Enter the location of titan (int) : ");
//        // Number of vertices
//        n = sc.nextInt();
//        if(n >=0 && n < 16){
//            // array of vectors is used
//            // to store the graph
//            // in the form of an adjacency list
//            ArrayList<ArrayList<Integer>> adj = new ArrayList<>();
//            for(int i = 0; i < n; i++){
//                adj.add(new ArrayList<>());
//            }
//
//            // Given Graph
//
//            addEdge(adj, 0, 1);
//            addEdge(adj, 0, 5);
//            addEdge(adj, 0, 7);
//            addEdge(adj, 1, 2);
//            addEdge(adj, 1, 4);
//            addEdge(adj, 1, 6);
//            addEdge(adj, 2, 3);
//            addEdge(adj, 2, 13);
//            addEdge(adj, 2, 11);
//            addEdge(adj, 3, 10);
//            addEdge(adj, 4, 6);
//            addEdge(adj, 4, 10);
//            addEdge(adj, 5, 6);
//            addEdge(adj, 5, 12);
//            addEdge(adj, 5, 7);
//            addEdge(adj, 6, 8);
//            addEdge(adj, 6, 15);
//            addEdge(adj, 7, 9);
//            addEdge(adj, 8, 10);
//            addEdge(adj, 9, 12);
//            addEdge(adj, 9, 15);
//            addEdge(adj, 10, 14);
//            addEdge(adj, 11, 13);
//            addEdge(adj, 13, 14);
//            addEdge(adj, 14, 15);
//
//            // Given source and destination
//            int source = 0;
//            int destination = n;
//
//            // Function Call
//            printShortestPaths(adj, n, source, destination);
//        }
//        }
// 
//    }
//}
