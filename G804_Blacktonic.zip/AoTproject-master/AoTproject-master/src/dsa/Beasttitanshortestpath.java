/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsa;




/**
 *
 * @author user
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;



public class Beasttitanshortestpath {
    public static ArrayList<List<Integer>> answer = new ArrayList<>();
    // No. of vertices in graph
    private final int v;
 
    // adjacency list
    private ArrayList<Integer>[] adjList;
 
    // Constructor
    public Beasttitanshortestpath(int vertices)
    {
 
        // initialise vertex count
        this.v = vertices;
 
        // initialise adjacency list
        initAdjList();
    }
 
    // utility method to initialise
    // adjacency list
    @SuppressWarnings("unchecked")
    private void initAdjList()
    {
        adjList = new ArrayList[v];
 
        for (int i = 0; i < v; i++) {
            adjList[i] = new ArrayList<>();
        }
    }
 
    // add edge from u to v
    public void addEdge(int u, int v)
    {
        // Add v to u's list.
        adjList[u].add(v);
    }
 
    // Prints all paths from
    // 's' to 'd'
    public void printAllPaths(int s, int d)
    {

        boolean[] isVisited = new boolean[v];
        ArrayList<Integer> pathList = new ArrayList<>();
 
        // add source to path[]
        pathList.add(s);
 
        // Call recursive utility
        printAllPathsUtil(s, d, isVisited, pathList);
    }
 
    // A recursive function to print
    // all paths from 'u' to 'd'.
    // isVisited[] keeps track of
    // vertices in current path.
    // localPathList<> stores actual
    // vertices in the current path
    private void printAllPathsUtil(Integer u, Integer d,
                                   boolean[] isVisited,
                                   List<Integer> localPathList)
    {
 
        if (u.equals(d)) {
            answer.add(new ArrayList<>(localPathList));
            // if match found then no need to traverse more till depth

        }

 
        // Mark the current node
        isVisited[u] = true;
 
        // Recur for all the vertices
        // adjacent to current vertex
        for (Integer i : adjList[u]) {
            if (!isVisited[i]) {
                // store current node
                // in path[]
                localPathList.add(i);
                printAllPathsUtil(i, d, isVisited, localPathList);

                // remove current node
                // in path[]
                localPathList.remove(i);
            }
        }
 
        // Mark the current node
        isVisited[u] = false;
    }
    
    public static ArrayList<Integer> buildarr(){
        ArrayList<Integer> Buildarr = new ArrayList<>();
        System.out.println("Enter the building nodes first i.e. 1 3 6 8 10 11 13 : ");
            Scanner in = new Scanner(System.in);
            String[] s=in.nextLine().split(" ");
            for(String c : s){
                Buildarr.add(Integer.parseInt(c));
            }
            return Buildarr;
    }
    
    public static ArrayList<Integer> titanarr(){
        ArrayList<Integer> Titanarr = new ArrayList<>();
        System.out.println("Enter the titan nodes second i.e. 2 12 14 : ");
            Scanner in = new Scanner(System.in);
            String[] s=in.nextLine().split(" ");
            for(String c : s){
                Titanarr.add(Integer.parseInt(c));
            }
            return Titanarr;
    }
        
        public static ArrayList<Integer> treearr(){
        ArrayList<Integer> Treearr = new ArrayList<>();
        System.out.println("Enter the tree nodes last i.e. 4 5 7 9 15: ");
            Scanner in = new Scanner(System.in);
            String[] s=in.nextLine().split(" ");
            for(String c : s){
                Treearr.add(Integer.parseInt(c));
            }
            return Treearr;
    }

            
        public static int checker(int coor, int intelli, int agility, ArrayList<Integer> treearr, ArrayList<Integer> buildarr, ArrayList<Integer> titanarr){
        int shortestN = 9999;
        int index = 0;
        for (int i = 0; i < answer.size(); i++) {
            List<Integer> answer1 = answer.get(i);
            int time = 0;
            for(int j : answer1){
                if(Arrays.asList(buildarr).contains(j)){
                    if(coor < 5){
                        time += 3;
                    }
                    else if(coor < 8){
                        time += 2;
                    }
                    else{
                        time +=1;
                    }
                }
                else if(Arrays.asList(titanarr).contains(j)){
                    if(intelli < 5){
                        time += 3;
                    }
                    else if(intelli < 8){
                        time += 2;
                    }
                    else{
                        time +=1;
                    }
                }
                else if(Arrays.asList(treearr).contains(j)){
                    if(agility < 5){
                        time += 3;
                    }
                    else if(agility < 8){
                        time += 2;
                    }
                    else{
                        time +=1;
                    }
                }
            }
            if(time < shortestN){
                shortestN = time;
                index = i;
            }
        }
        return index;
    }

//        for(List<Integer> answer1 : answer){
//                if( shortestN == answer1.size()){
//                    System.out.print(answer1.get(0));
//                    for(int i = 1; i < answer1.size(); i++){
//                        System.out.print("-->" + answer1.get(i));
//                    }
//                    System.out.println("");
//                }
//            }

        



// Driver program
    public static void main(String[] args)
    {
        // Create a sample graph
        Beasttitanshortestpath g = new Beasttitanshortestpath(16);
        g.addEdge(0, 1);
        g.addEdge(0, 5);
        g.addEdge(0, 7);
        g.addEdge(1, 2);
        g.addEdge(1, 4);
        g.addEdge(1, 6);
        g.addEdge(2, 3);
        g.addEdge(2, 13);
        g.addEdge(2, 11);
        g.addEdge(3, 10);
        g.addEdge(4, 6);
        g.addEdge(4, 10);
        g.addEdge(5, 6);
        g.addEdge(5, 12);
        g.addEdge(5, 7);
        g.addEdge(6, 8);
        g.addEdge(6, 15);
        g.addEdge(7, 9);
        g.addEdge(8, 10);
        g.addEdge(9, 12);
        g.addEdge(9, 15);
        g.addEdge(10, 14);
        g.addEdge(11, 13);
        g.addEdge(13, 14);
        g.addEdge(14, 15);
        ArrayList<Integer> Buildarr = null;
        ArrayList<Integer> Titanarr = null;
        ArrayList<Integer> Treearr = null;
        do{
            System.out.println("make all number of nodes sum to 16");
            Buildarr = buildarr();
            System.out.println(Buildarr.size());
            Titanarr = titanarr();
            System.out.println(Titanarr.size());
            Treearr = treearr();
            System.out.println(Treearr.size());

        }while((Titanarr.size() + Buildarr.size() + Treearr.size()) != 15);
        
        
        System.out.print("Enter location of Beast Titan: ");
        // arbitrary source
        int s = 0;
        // arbitrary destination
        Scanner in = new Scanner(System.in);
        int d = in.nextInt();
        
        
        g.printAllPaths(s, d);
        
        
        LinkedList<characteristic> list = new LinkedList<>();
        Scanner sc = new Scanner(System.in);
        int size = 0;

        String file_path = "characteristics.txt";

        //2.1
        //store and print data 
        try {
            File f = new File(file_path);
            Scanner inputStream = new Scanner(new FileInputStream(f));
            boolean isAdded = false;

            while (inputStream.hasNextLine()) {
                String name = inputStream.nextLine();
                int height = Integer.parseInt(inputStream.nextLine());
                int weight = Integer.parseInt(inputStream.nextLine());
                int strength = Integer.parseInt(inputStream.nextLine());
                int agility = Integer.parseInt(inputStream.nextLine());
                int intelligence = Integer.parseInt(inputStream.nextLine());
                int coordination = Integer.parseInt(inputStream.nextLine());
                int leadership = Integer.parseInt(inputStream.nextLine());
                size++;

                characteristic character = new characteristic(name, height, weight, strength, agility, intelligence, coordination, leadership);
                isAdded = list.add(character);
//                System.out.println(character.toString());
//                System.out.println();

                if (isAdded) {
                    continue;
                } else {
                    System.out.println("Not added!");
                    break;
                }

            }
            inputStream.close();
        } catch (FileNotFoundException e) {
            System.out.println(e);
        }
        
        
        
        in.nextLine();
        boolean statustoContinue = true;
        do{
            System.out.print("Enter character you want to fight: ");
            String name = in.nextLine();
                
            for(characteristic c : list){
                if(c.getName().equals(name)){
                    int coor = c.getCoordination();
                    int intelli = c.getIntelligence();
                    int agility = c.getAgility();
                    int index = checker(coor, intelli, agility, Treearr, Buildarr, Titanarr);
//                    System.out.println("size of answer is " + answer.size());
//                    System.out.println(index);
                    System.out.println(answer.get(index).toString());
                    statustoContinue = false;
                }
            }
            if (name.equalsIgnoreCase("quit")) {
                statustoContinue = false;
            }
        }while(statustoContinue);
        
        
        

            //min # of nodes to complete path
//            for (List<Integer> answer1 : answer) {
//                if(shortestN > answer1.size()){
//                    shortestN = answer1.size();
//                }
//            }
//            if(globalshortestN > shortestN){
//                globalshortestN = shortestN;
//                atwhicharr = z;
//            }


    }
}
