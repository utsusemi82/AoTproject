# AoTproject

Kindly push your codes to this repo. Thanks!

- [x] [2.1 Eren’s Allies](https://github.com/utsusemi82/AoTproject/tree/60333e3b12a686e303c049812145af831e6b309c/src/dsa)

- [ ] 2.2 Soldiers Arrangement and Grouping
- [ ] 2.3 Titan Evaluation and Killing Priority
- [ ] 2.3 Scouting Mission inside the Wall
- [ ] 2.4 Best Path to Kill Titan
- [ ] 2.5 Marley word converter
- [ ] 2.6 Protecting Wall of Maria

