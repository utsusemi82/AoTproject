/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project;
import java.util.*;

public class HashMap {
    public String RSAConvert(String input){
        RSA rsa = new RSA();
        try{
            String encryptedMessage = rsa.encrypt(input);
            String decryptedMessage = rsa.decrypt(encryptedMessage);
        }catch (Exception ingored){}
        return encryptedMessage+"\n"+decryptedMessage;
    }

    private static char[] dict = { 'j', 'c', 't', 'a', 'k', 'z', 's', 'i', 'w', 'x', 'o', 'n', 'g', 'b', 'f', 'h', 'l',
            'd', 'e', 'y', 'm', 'v', 'u', 'p', 'q', 'r' };

    public static String HMConvert(String input) {
        return HMConvert(input, 0);
    }
    
    public static String HMConvert(String sourceString, int shiftValue) {
        String input = "";
        for (char c : sourceString.toCharArray()) 
        input += (char) (c + shiftValue);
        String output = "";

        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == '(') {
                int j;
                for (j = i; input.charAt(j) != ')'; j++)
                    ;
                for (int k = j - 1; k > i; k--) {
                    if (input.charAt(k) == '$')
                        output += ' ';
                    else if (input.charAt(k) == '^')
                        continue;
                    else {
                        output += input.charAt(k) >= 'a' && input.charAt(k) <= 'z' ? dict[input.charAt(k) - 'a']
                                : input.charAt(k);
                        if (input.charAt(k - 1) == '^')
                            output = output.substring(0, output.length() - 1)
                                    + (char) (output.charAt(output.length() - 1) - 'a' + 'A');
                    }
                }
                i = j;
            } else if (input.charAt(i) == '$')
                output += ' ';
            else if (input.charAt(i) == '^')
                continue;
            else {
                output += input.charAt(i) >= 'a' && input.charAt(i) <= 'z' ? dict[input.charAt(i) - 'a']
                        : input.charAt(i);
                if (i > 0 && input.charAt(i - 1) == '^')
                    output = output.substring(0, output.length() - 1)
                            + (char) (dict[input.charAt(i) - 'a'] - 'a' + 'A');
            }
        }

        return output;
    }
}

